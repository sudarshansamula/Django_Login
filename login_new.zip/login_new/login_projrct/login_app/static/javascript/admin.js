"use strict";
var limited_users = 0;
var isBillingView = false;
var users_session = "";
var users_session_count = ""
var isAdmin = false;
$(document).ready(function() {
    createuserFilterOpt()
});
function createuserFilterOpt() {
    getEle('prev&next').style.display = "none";
    $("#total_users__records").html('');
    $("#manage_users").prepend('<div id="add_user_id" class="align_divS"><label class="control-label label_admin">Add User </label><label style="margin-left:5px;"><a href="javascript:void(0)" onclick="createPaidUser()" title="adduser"><i class="fa fa-user-plus fa-1g" style="color:#000;"></i></a></label></div>');
   showUserInfoList();
}

function showUserInfoList() {
    $("#users_info_body").html('');
    $("#users_info_body").append("<table cellspacing='0' border='0' class='nowrap stripe hover table2excel '  style='width:100%'  id='user_info_table'></table>");
    var user_list_url = "/getUsersInfo";
    var resp = sendSyncReq(user_list_url);
    var result = JSON.parse(resp);
    console.log("result : ",result)
    var data=result.data;
    isAdmin=result.isAdmin;
    if (result.message == "success") {
        if (data.length == 0) {
            return $("#users_info_body").append("<br><br><h4 style='font-weight:bold;font-size:14px;'>No records found</h4>");
        }
        var aoColumns = Object.keys(data[0]).map(function(v) {
            return { "data": v };
        });
        if(!isAdmin){
            getEle("title_ele").innerHTML="User-view";
            getEle("add_user_id").style.display="none";
        }else{
            aoColumns.push({"data":"Delete" });
            for (var d of data) {
                    d["Delete"] = '<a class="fa fa-trash" aria-hidden="true" title="Delete user" style="cursor: pointer;color:red;" onclick="deleteUserprofile('+d.id+')"></a>';
            }
        }
        
        $('#user_info_table').html('<thead class="thead_style"><th>' + getCapTableHeaders(Object.keys(data[0])).join('</th><th>') + '</th></thead>')

        $('#user_info_table').dataTable({
            "aaData": data,
            "retrieve": true,
            "aoColumns": aoColumns,
            "sScrollY": "350px",
            "bPaginate": false,
            "sScrollX": "auto",
            "bPaginate": false,
            "dom": 'Rlfrtip',
            "fixedColumns": true,
            "columnDefs": [{
                targets: -1,
                orderable: false
            }]
        });
    } else {
        return alert(result.data);
    }

}
function createPaidUser() {
    $("#createProfileId").remove();
    var divId = "createProfileId";
    var formStr = addOrEditProfile(divId);
    $("body").append(formStr);
    $("#createProfileId").modal();
    //featuresSel(configObj);
    var formObj = $("#createProfileId form")[0];
    //onChangeUserType(formObj);

    $("#createProfileId div[name='user_status_div']").hide();

    $("#createProfileId  button[name='sub_but']").click(function() {
        var insertInfo = {};
        insertInfo["name"] = formObj.name.value.trim();
        insertInfo["user_type"] = formObj.user_type.value.trim();
        insertInfo["email"] = formObj.email.value.trim();
        insertInfo["password"] = formObj.password.value.trim();
        insertInfo["feed_back"] = formObj.feed_back.value.trim();
        var url = "/createUser?insertInfo=" + JSON.stringify(insertInfo),
            resp = sendSyncReq(url),
            result = JSON.parse(resp);
        //console.log(result)
        if (result.message == "success") {
            $('#createProfileId').modal('hide');
            alert(result.data);
            showUserInfoList();
        } else {
            alert(result.data);
        }
        //$('#createProfileId').modal('hide');
    });
};
function deleteUserprofile(dltID){
    var url = "/deleteUser?id="+dltID;
    var resp = sendSyncReq(url),
    result = JSON.parse(resp);
    alert(result.data);
    showUserInfoList();
};
function dologout(){
    var url = "/logout";
    var resp = sendSyncReq(url);
    window.onbeforeunload = null;
    window.location.href = "/logout";

};

function addOrEditProfile(divId){
    var user_type_str = '<div class="form-group" style="margin-left:-60px;margin-top:-10px;"> '+
                            '<label for="name" class="col-sm-3 control-label" style="text-align:right">'+
                                'User Type'+
                            '</label>  '+
                            '<div class="col-sm-9"> '+
                                '<select class="form-control-static" name="user_type" style="width:48%;min-height:25px;border-radius:none">'+
                                        '<option value=admin>ADMIN</option>'+
                                        '<option value=user>User</option>'+
                                '</select>'+
                            '</div>' +
                        '</div>';
    var user_info_str='<div class="form-group" style="margin-left:-60px;"> '+
                    '<label for="first_name" class="col-sm-3 control-label" style="text-align: right">'+
                        'Name'+
                    '</label>'+
                    '<div class="col-sm-9">'+
                        '<input type="text" name="name" value="" placeholder="First Name" style="width:48%;height:30px">'+
                    '</div>'+
            '</div>'+'<div class="form-group" style="margin-left:-60px;"> '+
                    '<label for="email" class="col-sm-3 control-label" style="text-align: right">'+
                        'Email'+
                    '</label>'+
                    '<div class="col-sm-9">'+
                        '<input type="text" name="email"   placeholder="abc@gmail.com" style="width:48%;height:30px">'+
                    '</div>'+
            '</div>'+'<div class="form-group" style="margin-left:-60px;"> '+
                    '<label for="email" class="col-sm-3 control-label" style="text-align: right">'+
                        'Password'+
                    '</label>'+
                    '<div class="col-sm-9">'+
                        '<input type="text" name="password"   placeholder="123456" style="width:48%;height:30px">'+
                    '</div>'+
            '</div>'+'<div class="form-group" style="margin-left:-60px;"> '+
                    '<label for="email" class="col-sm-3 control-label" style="text-align: right">'+
                        'Feedback'+
                    '</label>'+
                    '<div class="col-sm-9">'+
                        '<input type="text" name="feed_back"   placeholder="He is Excelent" style="width:48%;height:30px">'+
                    '</div>'+
            '</div>';
    var form_str = '<div class="modal fade" data-backdrop="static" data-keyboard="false" id='+divId+'>'+
                '<div class="modal-dialog">'+
                    '<div class="modal-content">'+
                        getModalHeader("Create Employe")+    
                        '<div class="modal-body customBody">'+
                            '<form class="form-horizontal">'+   
                                user_info_str+
                                user_type_str+
                                '</form>'+
                                '</div>'+
                                getModalFooter("Submit")+
                    '</div>'+
                '</div>'+
            '</div>';
    return form_str;     
};
function getModalFooter(update_or_add){
    return '<div class="modal-footer">'+
                                '<button type="button"  value="'+update_or_add+'" name="sub_but" class="btn btn-primary" style="float:right">'+update_or_add+
                                '</button>'+
                        '</div>';
}

function getModalHeader(title){
    return '<div class="modal-header">'+
    '<button type="button" class="close" title="Close" data-dismiss="modal">&times;</button>'+
                            '<h4 class="head_font">'+title+'</h4>'+
                        '</div>';
}

function getCapTableHeaders(h) {
    if (h instanceof Array) {
        for (var i in h) {
            h[i] = getCapTableHeaders(h[i]);
        }
        return h;
    }
    if (!h || h === "")
        return h;
    var hd = h.split("_");
    hd = hd.join(" ");
    return hd.charAt(0).toUpperCase() + hd.slice(1);;
};