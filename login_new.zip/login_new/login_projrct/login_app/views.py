from django.shortcuts import render,render_to_response,redirect
import json
from django.http import HttpResponse
from login_app.models import UserInfo
from django.template import RequestContext
from login_app.forms import LoginForm
from django.db import connection,transaction
cursor = connection.cursor()
# Create your views here.
def loadHomepage(request):
    #return render_to_response('home.html')
    return render(request,'home.html')
def loginUser(request):
    data={'email':"",'password':""}
    if request.method == "POST":
        data['email']=request.POST.get('email')
        data['password']=request.POST.get('password')
    if valiDateExistingorNOt(data,request):
        return render_to_response('admin.html')
    else:
        return render_to_response('home.html') 
def  valiDateExistingorNOt(data,request):
    email = data['email']   
    #password = data['password']
    sel_qry="select * from user_info where email="+json.dumps(email)
    all_objects= UserInfo.objects.raw(sel_qry)
    user_info={"email":email}
    for p in all_objects:
        user_info["user_type"]=p.user_type
        user_info["password"]=p.password
    isAdmin=False
    isValidUser=False
    if "user_type" in user_info:
        if user_info['user_type'] == "admin":
            isAdmin=True
        isValidUser=True
    request.session['isAdmin']=isAdmin
    return  isValidUser
def getUsersInfo(request):
    sql_query = "select *from user_info where user_type ='user'"
    print("Value***",request.session['isAdmin'])
    if request.session.get('isAdmin'):
      sql_query = "select *from user_info"
    res_obj = {}
    all_objects= UserInfo.objects.raw(sql_query)
    sel_rows=[]
    for p in all_objects:
        tempObj={}
        tempObj["id"]=p.id
        tempObj["email"]=p.email
        tempObj["name"]=p.name
        tempObj["password"]=p.password
        tempObj["user_type"]=p.user_type
        tempObj["feed_back"]=p.feed_back    
        sel_rows.append(tempObj)
    res_obj = {"message":"success","data":sel_rows,"isAdmin":request.session.get('isAdmin')}    
    return HttpResponse(json.dumps(res_obj))
def logout(request):
    request.session.clear()
    return redirect(loadHomepage)
def createUser(request):
    print("****",request.method)
    insertObj=json.loads(request.GET.get('insertInfo'))
    print("insert_obj****",insertObj)
    email=insertObj['email']
    name=insertObj['name']
    password=insertObj['password']
    user_type=insertObj['user_type']
    feed_back=insertObj['feed_back']
    insert_query ="""insert into user_info(email,password,name,user_type,feed_back) values(%s,%s,%s,%s,%s)"""
    res_obj = {}
    valuesArr=(email,password,name,user_type,feed_back)
    cursor.execute(insert_query,valuesArr)
    transaction.commit()
    print("completed***")
    res_obj = {"message":"success","data":"Create User Successfully"}
    return HttpResponse(json.dumps(res_obj))
def deleteUser(request):
    dltID=request.GET.get('id')
    dltquery="delete from user_info where id="+dltID
    cursor.execute(dltquery)
    transaction.commit()
    res_obj = {"message":"success","data":"Deleted User Successfully"}
    return HttpResponse(json.dumps(res_obj))